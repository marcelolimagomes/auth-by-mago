package com.mago.ai.base.base_ai.controller;

import com.mago.ai.base.base_ai.entity.Profile;
import com.mago.ai.base.base_ai.service.ProfileService;
import com.mago.ai.base.base_ai.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/profile")
public class ProfileController {

    private  ProfileService profileService;
    private  UserService userService;

    @Autowired
    public void setRoleService(ProfileService profileService) {
        this.profileService = profileService;        
    }

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;        
    }


    @GetMapping
    public ResponseEntity<Profile> getProfile() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Long userId = userService.findByUsername(username).get().getId();
        Profile profile = profileService.findByUserId(userId);
        return ResponseEntity.ok(profile);
    }

    @PutMapping
    public ResponseEntity<Profile> updateProfile(@RequestBody Profile profile) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Long userId = userService.findByUsername(username).get().getId();
        Profile existingProfile = profileService.findByUserId(userId);
        existingProfile.setFirstName(profile.getFirstName());
        existingProfile.setLastName(profile.getLastName());
        existingProfile.setEmail(profile.getEmail());
        return ResponseEntity.ok(profileService.save(existingProfile));
    }
}

package com.mago.ai.base.base_ai.service;

import com.mago.ai.base.base_ai.entity.Profile;
import com.mago.ai.base.base_ai.repository.ProfileRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {

    private ProfileRepository profileRepository;

    @Autowired
    public void setProfileRepository(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    public Profile findByUserId(Long userId) {
        return profileRepository.findByUserId(userId);
    }

    public Profile save(Profile profile) {
        return profileRepository.save(profile);
    }
}
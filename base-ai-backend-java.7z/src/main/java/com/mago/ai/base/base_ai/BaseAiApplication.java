package com.mago.ai.base.base_ai;

import com.mago.ai.base.base_ai.entity.Profile;
import com.mago.ai.base.base_ai.entity.Role;
import com.mago.ai.base.base_ai.entity.User;
import com.mago.ai.base.base_ai.service.RoleService;
import com.mago.ai.base.base_ai.service.UserService;
import com.mago.ai.base.base_ai.service.ProfileService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.HashSet;

@SpringBootApplication(scanBasePackages = "com.mago.ai.base.base_ai")
public class BaseAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BaseAiApplication.class, args);
    }

    @Bean
    CommandLineRunner init(UserService userService, RoleService roleService, ProfileService profileService) {
        return args -> {
            // Criar roles iniciais
            Role adminRole = new Role();
            adminRole.setName("ADMIN");
            roleService.save(adminRole);

            Role userRole = new Role();
            userRole.setName("USER");
            roleService.save(userRole);

            // Criar usuário admin
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            admin.setRoles(new HashSet<>() {{ add(adminRole); add(userRole); }});
            userService.save(admin);

            Profile adminProfile = new Profile();
            adminProfile.setFirstName("Admin");
            adminProfile.setLastName("User");
            adminProfile.setEmail("admin@example.com");
            adminProfile.setUser(admin);
            profileService.save(adminProfile);

            // Criar usuário comum
            User user = new User();
            user.setUsername("user");
            user.setPassword("user123");
            user.setRoles(new HashSet<>() {{ add(userRole); }});
            userService.save(user);

            Profile userProfile = new Profile();
            userProfile.setFirstName("Regular");
            userProfile.setLastName("User");
            userProfile.setEmail("user@example.com");
            userProfile.setUser(user);
            profileService.save(userProfile);
        };
    }
}
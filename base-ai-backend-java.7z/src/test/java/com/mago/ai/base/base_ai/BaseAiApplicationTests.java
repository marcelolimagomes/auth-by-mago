package com.mago.ai.base.base_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseAiApplicationTests {

	@Test
	void contextLoads() {
	}

}

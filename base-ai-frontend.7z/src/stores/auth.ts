import { defineStore } from 'pinia';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

interface User {
  id: string;
  username: string;
  roles: string[];
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null as User | null,
    token: localStorage.getItem('token') || '',
  }),
  getters: {
    isAuthenticated: (state) => !!state.token,
    isAdmin: (state) => state.user?.roles.includes('ADMIN') || false,
  },
  actions: {
    async login(username: string, password: string) {
      try {
        const response = await axios.post('http://your-api-url/auth/login', { username, password });
        this.token = response.data.token;
        localStorage.setItem('token', this.token);
        this.user = jwtDecode<User>(this.token);
      } catch (error) {
        console.error('Login failed', error);
      }
    },
    logout() {
      this.user = null;
      this.token = '';
      localStorage.removeItem('token');
    },
  },
});
<template>
  <div class="container mt-5">
    <h2>Roles Management</h2>
    <button class="btn btn-success mb-3" @click="addRole">Add Role</button>
    <ul class="list-group">
      <li v-for="role in roles" :key="role.id" class="list-group-item d-flex justify-content-between">
        <span>{{ role.name }}</span>
        <div>
          <button class="btn btn-warning btn-sm me-2" @click="editRole(role)">Edit</button>
          <button class="btn btn-danger btn-sm" @click="deleteRole(role.id)">Delete</button>
        </div>
      </li>
    </ul>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import axios from 'axios';
import { Role } from '../types';
import { URL_ROLES } from '../constants';

export default defineComponent({
   
  setup() {
    const roles = ref<Role[]>([]);

    const fetchRoles = async () => {
      const response = await axios.get(URL_API, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      roles.value = response.data;
    };

    const addRole = async () => {
      const name = prompt('Enter role name');
      if (name) {
        await axios.post(Const., { name }, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        });
        fetchRoles();
      }
    };

    const editRole = async (role: Role) => {
      const name = prompt('Edit role name', role.name);
      if (name) {
        await axios.put(`${URL_API}/${role.id}`, { name }, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        });
        fetchRoles();
      }
    };

    const deleteRole = async (id: string) => {
      if (confirm('Are you sure?')) {
        await axios.delete(`${URL_API}/${id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        });
        fetchRoles();
      }
    };

    fetchRoles();
    return { roles, addRole, editRole, deleteRole };
  },
});
</script>
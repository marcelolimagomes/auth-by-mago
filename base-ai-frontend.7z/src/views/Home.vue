<template>
  <div class="container mt-5">
    <h2>Welcome, {{ authStore.user?.username }}</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useAuthStore } from '../stores/auth';

export default defineComponent({
  setup() {
    const authStore = useAuthStore();
    return { authStore };
  },
});
</script>
<template>
  <div class="container mt-5">
    <h2>Profile</h2>
    <form @submit.prevent="saveProfile">
      <div class="mb-3">
        <input v-model="profile.firstName" class="form-control" placeholder="First Name" required />
      </div>
      <div class="mb-3">
        <input v-model="profile.lastName" class="form-control" placeholder="Last Name" required />
      </div>
      <div class="mb-3">
        <input v-model="profile.email" type="email" class="form-control" placeholder="Email" required />
      </div>
      <button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import axios from 'axios';
import { Profile } from '../types';
import { URL_PROFILE } from '../constants';

export default defineComponent({
  setup() {
    const profile = ref<Profile>({
      id: '',
      firstName: '',
      lastName: '',
      email: '',
    });

    const fetchProfile = async () => {
      const response = await axios.get(URL_PROFILE, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      profile.value = response.data;
    };

    const saveProfile = async () => {
      await axios.put(URL_PROFILE, profile.value, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      alert('Profile saved!');
    };

    fetchProfile();
    return { profile, saveProfile };
  },
});
</script>
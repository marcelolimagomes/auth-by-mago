export interface Role {
  id: string;
  name: string;
}

export interface Profile {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}


const BASE_URL = 'http://localhost:3000/api';

export class Const {
  public URL_API: string = BASE_URL;
  public URL_LOGIN: string = `${BASE_URL}/login`;
  public URL_ROLES: string = `${BASE_URL}/roles`;
  public URL_PROFILE: string = `${BASE_URL}/profile`;
}
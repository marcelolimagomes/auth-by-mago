import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '../stores/auth';
import Login from '../views/Login.vue';
import Home from '../views/Home.vue';
import Roles from '../views/Roles.vue';
import Profile from '../views/Profile.vue';

const routes = [
  { path: '/login', component: Login },
  { 
    path: '/', 
    component: Home, 
    meta: { requiresAuth: true } 
  },
  { 
    path: '/roles', 
    component: Roles, 
    meta: { requiresAuth: true, requiresAdmin: true } 
  },
  { 
    path: '/profile', 
    component: Profile, 
    meta: { requiresAuth: true } 
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login');
  } else if (to.meta.requiresAdmin && !authStore.isAdmin) {
    next('/');
  } else {
    next();
  }
});

export default router;
export const BASE_URL = 'http://localhost:3000/api';
export const URL_LOGIN: string = `${BASE_URL}/login`;
export const URL_ROLES: string = `${BASE_URL}/roles`;
export const URL_PROFILE: string = `${BASE_URL}/profile`;
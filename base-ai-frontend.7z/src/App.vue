<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <router-link class="navbar-brand" to="/">Vue JWT App</router-link>
      <div v-if="authStore.isAuthenticated" class="navbar-nav">
        <router-link class="nav-link" to="/profile">Profile</router-link>
        <router-link v-if="authStore.isAdmin" class="nav-link" to="/roles">Roles</router-link>
        <button class="btn btn-link nav-link" @click="authStore.logout">Logout</button>
      </div>
    </div>
  </nav>
  <router-view />
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useAuthStore } from './stores/auth';

export default defineComponent({
  setup() {
    const authStore = useAuthStore();
    return { authStore };
  },
});
</script>